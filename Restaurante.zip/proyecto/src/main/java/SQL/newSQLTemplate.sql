
drop database if exists bdrestaurante;
create database bdrestaurante;
use bdrestaurante;

create table producto(
codp int primary key auto_increment,
desp varchar(20),
precio numeric(6,1)

);

create table consumo(
idcod int primary key auto_increment,
nombre VARCHAR(50) NOT NULL,
importe DECIMAL(28, 2) NOT NULL,   
fecha_hora DATETIME DEFAULT CURRENT_TIMESTAMP
);



create table detalle(
idcod int,
codp  int,
can   int
);

create table login(
usuario varchar(30) not null primary key,
clave  blob,

);

insert into  producto values(null,'Arroz con Pollo',34);
insert into producto values(null,'Lomo Saltado   ',75);
insert into producto values(null,'Aji de Gallina ',30);
insert into producto values(null,'Frejol con seco',50);
insert into producto values(null,'Seco de cabrito',38;
insert into producto values(null,'Pachamanca     ',38);
insert into producto values(null,'Ceviche        ',48);
insert into producto values(null,'Ratatuille     ',45);
insert into producto values(null,'Torta helada   ',70);


insert into login values('admin', aes_encrypt('alfa24','1231'));

drop procedure if exists spadiconsumo;
DELIMITER //
create procedure spadiconsumo(cli varchar(30),tot numeric(8,1))
begin
  INSERT INTO consumo VALUES(NULL,cli,tot,current_date());
  select max(idcod) from consumo;
end //
DELIMITER ;


DELIMITER $$
CREATE TRIGGER tg_del_conxdet
AFTER DELETE ON consumo
FOR EACH ROW
BEGIN
    DELETE FROM detalle WHERE idcod = OLD.idcod;
END $$
DELIMITER ;


DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `obtot`(IN `id_consumo` INT)
BEGIN
    SELECT p.desp, p.precio,d.can, (d.can * p.precio) AS total
    FROM detalle d
    JOIN producto p ON d.codp = p.codp
    WHERE d.idcod = id_consumo;
END$$
DELIMITER ;



