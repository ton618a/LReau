
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.*;
import java.util.List;


import util.MySQLConexion;



import Restaurante.Consumo;
import Restaurante.Detalle;
import Restaurante.Detcomp;

import Restaurante.Producto;
import Restaurante.Usuario;
import java.sql.*;


public class Negocio {
    
   
     
      public int  adicion(String cli, List<Detalle> lista){
     Connection cn=MySQLConexion.getConexion();
     String sql="{call spadiconsumo(?,?)}";
     int idcod=0;
     double tot=0;
     for(Detalle x:lista)tot=tot+x.totpro();
     try{
     CallableStatement st=cn.prepareCall(sql);
     //relacionar cada ? con ep
     st.setString(1,cli);
     st.setDouble(2, tot);
     ResultSet rs=st.executeQuery();
     rs.next();
     idcod=rs.getInt(1);
     
     String sql2="insert into detalle values(?,?,?)";
     PreparedStatement st2=cn.prepareStatement(sql2);
     for(Detalle x:lista){
         st2.setInt(1, idcod);
         st2.setInt(2,x.getCodp());
         st2.setInt(3, x.getCantidad());
         st2.executeUpdate();
     }
     }catch(Exception ex){
         ex.printStackTrace();
     }
     return idcod;
    } 

     public void anula(int idcod){
     Connection cn=MySQLConexion.getConexion();
     String sql="delete from consumo where idcod=?";
     try{
     PreparedStatement st=cn.prepareStatement(sql);
     //relacionar cada ? con ep
     st.setInt(1,idcod);
     st.executeUpdate();
     }catch(Exception ex){
         ex.printStackTrace();
     }
 } 
 
     
     
 public List<Consumo> lista(){
    List<Consumo> lis=new ArrayList(); 
    Connection cn=MySQLConexion.getConexion();
    String sql="select idcod,nombre,Importe, fecha_hora"+
            " from consumo";
    
    try{
     PreparedStatement st=cn.prepareStatement(sql);
     ResultSet rs=st.executeQuery();
     while(rs.next()){//lee filax fila
        Consumo c =new Consumo();
        c.setIdcod(rs.getInt(1));
        c.setNombre(rs.getString(2));
        c.setImporteTotal(rs.getDouble(3));
         c.setFechaHora(rs.getTimestamp(4).toLocalDateTime());
        
        lis.add(c);
     }
    }catch(Exception ex){
        ex.printStackTrace();
    }
    return lis;
    }
     public List<Producto> lisProducto(){
    List<Producto> lis =new ArrayList(); 
    Connection cn=MySQLConexion.getConexion();
    String sql="select codp,desp,precio from producto";
    
    try{
     PreparedStatement st=cn.prepareStatement(sql);
     ResultSet rs=st.executeQuery();
     while(rs.next()){//lee filax fila
        Producto p=new Producto();
        p.setCodp(rs.getInt(1));
        p.setNompro(rs.getString(2));
        p.setPrecio(rs.getDouble(3));
        lis.add(p);
     }
    }catch(Exception ex){
        ex.printStackTrace();
    }
    return lis;
 }
 
 
     public Consumo Busca(int idcod){
   Consumo c = null; 
    Connection cn=MySQLConexion.getConexion();
    //String sql="select id_consumo,nombre,importe"+ " from consumo where id_consumo";       
    String sql = "SELECT idcod, nombre, importe,fecha_hora FROM consumo WHERE idcod = ?";
     try{
     PreparedStatement st=cn.prepareStatement(sql);
     st.setInt(1, idcod);
     ResultSet rs=st.executeQuery();
     if (rs.next()){//lee filax fila
        c=new Consumo();
        c.setIdcod(rs.getInt(1));
        c.setNombre(rs.getString(2));
        c.setImporteTotal(rs.getDouble(3));
        c.setFechaHora(rs.getTimestamp(4).toLocalDateTime());
        
     }
    }catch(Exception ex){
        ex.printStackTrace();
    }
    return c;
    }
     
     
     //prod 
     
      public void adicion(Producto p){
     Connection cn=MySQLConexion.getConexion();
     String sql="insert into producto values(null,?,?)";
     try{
     PreparedStatement st=cn.prepareStatement(sql);
     //relacionar cada ? con ep
     st.setString(1,p.getNompro());
     st.setDouble(2,p.getPrecio());
   
     st.executeUpdate();
     }catch(Exception ex){
         ex.printStackTrace();
     }
 } 
 /**
     public void cambia(Producto p) {
    Connection cn = MySQLConexion.getConexion();
    String sql = "UPDATE producto SET desp=?, precio=? WHERE codp=?";
    try {
        PreparedStatement st = cn.prepareStatement(sql);
        // Relacionar cada ? con el producto
        st.setString(1, p.getNompro());
        st.setDouble(2, p.getPrecio());
        st.setInt(3, p.getcodp());  

        st.executeUpdate();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
}**/

 //anular
 public void eliminar(int codp){
     Connection cn=MySQLConexion.getConexion();
     String sql="delete from producto where codp=?";
     try{
     PreparedStatement st=cn.prepareStatement(sql);
     //relacionar cada ? con ep
     st.setInt(1,codp);
     st.executeUpdate();
     }catch(Exception ex){
         ex.printStackTrace();
     }
 } 
 public List<Detcomp> lisDetcomp(int an){
    List<Detcomp> lis=new ArrayList(); 
    Connection cn=MySQLConexion.getConexion();
    String sql="{call obtot(?)}";
    
    try{
     CallableStatement st=cn.prepareCall(sql);
     st.setInt(1, an);
     ResultSet rs=st.executeQuery();
     while(rs.next()){//lee filax fila
        Detcomp d=new Detcomp();
        d.setDesp(rs.getString(1));
        d.setPrecio(rs.getDouble(2));
        d.setCan(rs.getInt(3));
        d.setTotal(rs.getDouble(4));

        lis.add(d);
     }
    }catch(Exception ex){
        ex.printStackTrace();
    }
    return lis;
    }
 
 
 
 public Usuario busca(String usr, String cla) {
    Usuario cli = null;
    Connection cn = MySQLConexion.getConexion();
    String sql = "SELECT * FROM login WHERE usuario=? AND cast(aes_decrypt(clave,'1231') as char)=?";

    try {
        PreparedStatement st = cn.prepareStatement(sql);
        st.setString(1, usr.trim());
        st.setString(2, cla.trim());
        ResultSet rs = st.executeQuery();
        if (rs.next()) {
            cli = new Usuario();
            cli.setUser(usr);
            // Aquí podrías asignar otros atributos del usuario si es necesario
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return cli;

  
  
 } 
 
 

 
 }



    

     

