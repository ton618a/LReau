/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import Restaurante.Consumo;
import Restaurante.Detcomp;
import dao.Negocio;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 *
 * @author ton
 */
public class FComprobante extends javax.swing.JFrame {
    Negocio obj= new Negocio();
    private int idcod;
    public FComprobante() {
        initComponents();
 
     }

   
    public void mostrarInformacion(int idcod) {
        this.idcod = idcod;
      
        verDatoArea(idcod);
   //     this.setVisible(true); // Mostrar el formulario
    }

    void verDatoArea(int idcod) {
        /**
         AreaCTxt.setText("idcod  "+idcod);
         Consumo b = obj.Busca(idcod);  // Buscar el Consumo
        if (b == null) {
        AreaCTxt.setText("No existe código");  // Mostrar un mensaje si no se encuentra el Consumo
        } else {
        AreaCTxt.setText("Código: " + b.getIdcod());
        AreaCTxt.append("\nNombre: " + b.getNombre());
        AreaCTxt.append("\nFecha y hora: " + b.getFechaHora());
        AreaCTxt.append("\n");
        AreaCTxt.append("\n Producto\tPrecio\tCant\tTotal");
        for (Detcomp x : obj.lisDetcomp(idcod)) {
            AreaCTxt.append("\n  " + x.getDesp() + "\t  " + x.getPrecio() + "\t  " + x.getCan() + "\t  " + x.getTotal());
         }
        AreaCTxt.append("\n" );
        AreaCTxt.append("\n Importe: " + b.getImporteTotal());
        }**/
        
        AreaCTxt.setText("idcod  " + idcod);
    Consumo b = obj.Busca(idcod);  // Buscar el Consumo
    if (b == null) {
        AreaCTxt.setText("No existe código");  // Mostrar un mensaje si no se encuentra el Consumo
    } else {
        AreaCTxt.setText("Código: " + b.getIdcod());
        AreaCTxt.append("\nNombre: " + b.getNombre());
        AreaCTxt.append("\nFecha y hora: " + b.getFechaHora());
        AreaCTxt.append("\n");
        AreaCTxt.append("\n Producto\t      Precio\t    Cant\t    Total");
        for (Detcomp x : obj.lisDetcomp(idcod)) {
            String line = String.format("  %-10s\t  %-10s\t  %-10s\t  %-10s", x.getDesp(), x.getPrecio(), x.getCan(), x.getTotal());
            AreaCTxt.append("\n" + line);
        }
        AreaCTxt.append("\n");
        AreaCTxt.append("\n Importe: " + b.getImporteTotal());
    }
    }
    
  
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        AreaCTxt = new javax.swing.JTextArea();
        imprimir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        AreaCTxt.setColumns(20);
        AreaCTxt.setRows(5);
        jScrollPane1.setViewportView(AreaCTxt);

        imprimir.setText("imprimir");
        imprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imprimirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(imprimir)
                .addGap(157, 157, 157))
            .addGroup(layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(79, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(imprimir)
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     
    private void imprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imprimirActionPerformed
        // TODO add your handling code here:
                                                     
    Document document = new Document();
    try {
        PdfWriter.getInstance(document, new FileOutputStream("Descargas"));
        document.open();
        String contenido = AreaCTxt.getText(); // Obtén el contenido del área de texto
        document.add(new Paragraph(contenido));
        document.close();
        System.out.println("Archivo PDF generado correctamente.");
    } catch (DocumentException | FileNotFoundException e) {
        e.printStackTrace();
    }

        this.setVisible(false);
    }//GEN-LAST:event_imprimirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FComprobante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FComprobante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FComprobante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FComprobante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FComprobante().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AreaCTxt;
    private javax.swing.JButton imprimir;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    
}
