
package Vista;

import Restaurante.Consumo;
import Restaurante.Detalle;
import Restaurante.Detcomp;
import Restaurante.Producto;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import dao.Negocio;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;


import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JOptionPane;



public class FRestaurante extends javax.swing.JFrame {
 Negocio obj=new Negocio();
     List<Detalle> lista=new ArrayList();

    public FRestaurante() {
        initComponents();
        this.setLocationRelativeTo(this);
        verdatos();
        verProductos();
      
    }
        
           
        void verdatos(){
         DefaultTableModel dt=(DefaultTableModel)lisTab.getModel();
            dt.setRowCount(0);
            for(Consumo x:obj.lista()){
             Object v[]={x.getIdcod(), x.getNombre(), x.getImporteTotal(), x.getFechaHora()};
                dt.addRow(v); 
            }
            
        } 
        
       
        
      
       //fila doble
      void verProductos() {
    DefaultTableModel dt1 = (DefaultTableModel) proTab.getModel();
    DefaultTableModel dt2 = (DefaultTableModel) propTab.getModel();

    dt1.setRowCount(0); // Limpiar filas existentes
    dt2.setRowCount(0); // Limpiar filas existentes

    List<Producto> listaProductos = obj.lisProducto();

    for (Producto x : listaProductos) {
        Object v[] = {x.getCodp(), x.getNompro(), x.getPrecio()};
        dt1.addRow(v);
        dt2.addRow(v);
    }
    
    
    
    }
        

     
    //hora y fecha
    LocalDate fechaActual = LocalDate.now();
    LocalTime horaActual = LocalTime.now();
    DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH:mm:ss");
    
    //consulta cod
    
    
    @SuppressWarnings("unchecked")
    
    
    void busdatos(String Buscado) {
    DefaultTableModel dt = (DefaultTableModel) lisTab.getModel();
    dt.setRowCount(0);

    for (Consumo x : obj.lista()) {
       
        try {
            int buscado = Integer.parseInt(Buscado);
            if (x.getIdcod() == buscado) {
                Object v[] = {x.getIdcod(), x.getNombre(), x.getImporteTotal(), x.getFechaHora()};
                dt.addRow(v);
            }
        } catch (NumberFormatException e) {
            // Manejar el caso en el que el texto no se pueda convertir a entero
            System.out.println("El texto buscado no es un número válido.");
        }
      }
    }

    void buscaProductos(String busqueda) {
    DefaultTableModel dt = (DefaultTableModel) proTab.getModel();
    dt.setRowCount(0);

    for (Producto x : obj.lisProducto()) {
        // Verificar si el nombre del producto contiene la cadena de búsqueda
        if (x.getNompro().toLowerCase().contains(busqueda.toLowerCase())) {
            Object v[] = {x.getCodp(), x.getNompro(), x.getPrecio()};
            dt.addRow(v);
        }
    }
}

  
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jMenuItem1 = new javax.swing.JMenuItem();
        jLabel2 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        codTxt = new javax.swing.JTextField();
        conBot = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaCTxt = new javax.swing.JTextArea();
        impBot = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        canTxt = new javax.swing.JTextField();
        ingBot = new javax.swing.JButton();
        genBot = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        nomTxt = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        proTab = new javax.swing.JTable();
        AnuBot = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        conTab = new javax.swing.JTable();
        nconTxt = new javax.swing.JTextField();
        totTxt = new javax.swing.JTextField();
        probTxt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        propTab = new javax.swing.JTable();
        proTxt = new javax.swing.JTextField();
        preTxt = new javax.swing.JTextField();
        ingpBot = new javax.swing.JButton();
        borBot = new javax.swing.JButton();
        codpTxt = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        lisTab = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        nomLTxt = new javax.swing.JTextField();
        eliBot = new javax.swing.JButton();
        cocTxt = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(jTable2);

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jTabbedPane1StateChanged(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel7.setText("Codigo");

        codTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codTxtActionPerformed(evt);
            }
        });

        conBot.setText("Consultar");
        conBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                conBotActionPerformed(evt);
            }
        });

        areaCTxt.setColumns(20);
        areaCTxt.setRows(5);
        jScrollPane2.setViewportView(areaCTxt);

        impBot.setText("imprimir");
        impBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                impBotActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(jLabel7)
                        .addGap(74, 74, 74)
                        .addComponent(codTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(conBot)
                            .addComponent(impBot))
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(144, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(codTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(128, 128, 128)
                        .addComponent(conBot)
                        .addGap(54, 54, 54)
                        .addComponent(impBot))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(59, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("consultar", jPanel1);

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setText("Cantidad");

        ingBot.setText("ingresar");
        ingBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingBotActionPerformed(evt);
            }
        });

        genBot.setText("Generar");
        genBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genBotActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombre");

        nomTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomTxtActionPerformed(evt);
            }
        });

        proTab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Producto", "Precio"
            }
        ));
        proTab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                proTabMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(proTab);
        if (proTab.getColumnModel().getColumnCount() > 0) {
            proTab.getColumnModel().getColumn(0).setPreferredWidth(2);
            proTab.getColumnModel().getColumn(2).setPreferredWidth(2);
        }

        AnuBot.setText("Anular");
        AnuBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AnuBotActionPerformed(evt);
            }
        });

        conTab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Producto", "Precio", "can", "TxP"
            }
        ));
        conTab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                conTabMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(conTab);
        if (conTab.getColumnModel().getColumnCount() > 0) {
            conTab.getColumnModel().getColumn(0).setPreferredWidth(2);
            conTab.getColumnModel().getColumn(2).setPreferredWidth(2);
            conTab.getColumnModel().getColumn(3).setPreferredWidth(1);
            conTab.getColumnModel().getColumn(4).setPreferredWidth(2);
        }

        nconTxt.setEditable(false);
        nconTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nconTxtActionPerformed(evt);
            }
        });

        totTxt.setEditable(false);

        probTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                probTxtActionPerformed(evt);
            }
        });
        probTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                probTxtKeyReleased(evt);
            }
        });

        jLabel4.setText("buscar");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(ingBot)
                .addGap(38, 38, 38)
                .addComponent(AnuBot)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(53, 53, 53)
                .addComponent(probTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(nomTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(canTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(45, 45, 45)))
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(genBot)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(nconTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(86, 86, 86))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(totTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nomTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(canTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ingBot)
                            .addComponent(AnuBot)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(probTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))))
                .addGap(34, 34, 34)
                .addComponent(genBot)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(nconTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(totTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))))
        );

        jTabbedPane1.addTab("ingreso", jPanel3);

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel5.setText("producto");

        jLabel6.setText("precio");

        propTab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Producto", "Precio"
            }
        ));
        propTab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                propTabMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(propTab);
        if (propTab.getColumnModel().getColumnCount() > 0) {
            propTab.getColumnModel().getColumn(0).setPreferredWidth(2);
            propTab.getColumnModel().getColumn(2).setPreferredWidth(2);
        }

        ingpBot.setText("ingresar");
        ingpBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingpBotActionPerformed(evt);
            }
        });

        borBot.setText("borrar");
        borBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borBotActionPerformed(evt);
            }
        });

        codpTxt.setEditable(false);
        codpTxt.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                codpTxtComponentHidden(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6))
                                .addGap(58, 58, 58)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(proTxt)
                                    .addComponent(preTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE))
                                .addGap(48, 48, 48)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(ingpBot)
                                    .addComponent(borBot)))
                            .addComponent(codpTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(proTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ingpBot))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(preTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(borBot)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(codpTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("productos", jPanel6);

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lisTab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Codigo", "Cliente", "Importe", "Fecha_hora"
            }
        ));
        lisTab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lisTabMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(lisTab);
        if (lisTab.getColumnModel().getColumnCount() > 0) {
            lisTab.getColumnModel().getColumn(0).setPreferredWidth(5);
            lisTab.getColumnModel().getColumn(2).setPreferredWidth(5);
            lisTab.getColumnModel().getColumn(3).setPreferredWidth(40);
        }

        jLabel10.setText("codigo");

        nomLTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomLTxtActionPerformed(evt);
            }
        });
        nomLTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nomLTxtKeyReleased(evt);
            }
        });

        eliBot.setText("eliminar");
        eliBot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliBotActionPerformed(evt);
            }
        });

        cocTxt.setEditable(false);
        cocTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cocTxtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel10)
                        .addGap(50, 50, 50))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(cocTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 272, Short.MAX_VALUE)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(nomLTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(eliBot))
                .addGap(81, 81, 81))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 548, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(nomLTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(cocTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(eliBot)))
                .addGap(34, 34, 34)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
        );

        jTabbedPane1.addTab("listado", jPanel4);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 27, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 106, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 638, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(29, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

        void limpiar(){
       
        
        
        nomTxt.setText("");
        canTxt.setText("");
     
        
         //limpiar lista
   
      
     
        
//      ImporteTotal = 0.0;
       // areaTxt.setText("");
        
    }
    boolean valida() { 
        String cad ="";
        if(canTxt.getText().length()==0)
        cad = cad + "la cantidad esta empy";
          if(nomTxt.getText().length()==0)
        cad = cad + "el nombre esta empy";
            if(cad.length()>0){
                JOptionPane.showMessageDialog(null, cad);
            return false;
            }else{
            return true;
        }
        }  
    
     boolean validap() { 
        String cad ="";
        if(preTxt.getText().length()==0)
        cad = cad + "la precio esta empty";
          if(proTxt.getText().length()==0)
        cad = cad + "el producto is empty";

            if(cad.length()>0){
                JOptionPane.showMessageDialog(null, cad);
            return false;
            }else{
            return true;
        }

        }
    
    
    private void codTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codTxtActionPerformed

    private void conBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_conBotActionPerformed

        int idcod=Integer.parseInt(codTxt.getText());
        Consumo b= obj.Busca(idcod);
        if (b==null) {
            areaCTxt.setText("no existe codigo"); return;
        }
         areaCTxt.setText("codigo: "+ b.getIdcod());
         areaCTxt.append("\nNombre "+  b.getNombre()); 
         areaCTxt.append("\nfechahora: " + b.getFechaHora());
        areaCTxt.append("\n ");
        areaCTxt.append("\nProducto\tPrecio\tCant\ttotal"); 
        for (Detcomp x : obj.lisDetcomp(idcod)) {
        areaCTxt.append("\n" + x.getDesp() + "\t" + x.getPrecio() + "\t" + x.getCan() + "\t" + x.getTotal());
        }
        areaCTxt.append("\nimporte: "+  b.getImporteTotal());    
    }//GEN-LAST:event_conBotActionPerformed

    private void jTabbedPane1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jTabbedPane1StateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jTabbedPane1StateChanged

    private void proTabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_proTabMouseClicked
        
    }//GEN-LAST:event_proTabMouseClicked

    private void nomTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomTxtActionPerformed

    private void genBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genBotActionPerformed
    int idcod=obj.adicion(nomTxt.getText(), lista);
    nconTxt.setText(""+idcod); 
    
    verdeta(); canTxt.setText("");
    probTxt.setText("");
    nomTxt.setText("");
    nconTxt.setText("");
    totTxt.setText("");
    lista=new ArrayList();    
    //para actualizar la lista
    verdatos();
    
   
    
    FComprobante fc = new FComprobante();
    fc.setVisible(true); 
    fc.mostrarInformacion(idcod); 
    
    //actualizar tabla conTab y proTab
    //DefaultTableModel dt = (DefaultTableModel) proTab.getModel();
    // dt.setRowCount(0);
    verProductos();
    verdeta();
  
    }//GEN-LAST:event_genBotActionPerformed

    private void ingBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingBotActionPerformed
        if(!valida()) return ;
     
        int f=proTab.getSelectedRow();
        if(f==-1){
            JOptionPane.showMessageDialog(null, "elija un plato");
            return;
        }
        Detalle t=new Detalle();
        t.setCantidad(Integer.parseInt(canTxt.getText()));
        t.setCodp(Integer.parseInt(proTab.getValueAt(f,0).toString()));
        t.setNompro(proTab.getValueAt(f, 1).toString());
        t.setPrecio(Double.parseDouble(proTab.getValueAt(f, 2).toString()));
        lista.add(t);
        verdeta(); canTxt.setText("");
        
  
    }//GEN-LAST:event_ingBotActionPerformed

    private void conTabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_conTabMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_conTabMouseClicked

    private void AnuBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AnuBotActionPerformed
        int f=conTab.getSelectedRow();
        if(f==-1){
               JOptionPane.showMessageDialog(null, "elija una fila en pedido");
            return;
        }
        lista.remove(f);
           verdeta();
    }//GEN-LAST:event_AnuBotActionPerformed

    private void probTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_probTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_probTxtActionPerformed

    private void probTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_probTxtKeyReleased
        // TODO add your handling code here:
        
    
     String busqueda = probTxt.getText().toLowerCase().trim();

    if (busqueda.isEmpty()) {
        verProductos();  // Llamar al método verProductos sin parámetros para mostrar todos los productos
    } else {
        buscaProductos(busqueda);  // Llamar al método verProductos con la cadena de búsqueda
    }


        
        
        
    }//GEN-LAST:event_probTxtKeyReleased

    private void propTabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_propTabMouseClicked
        // TODO add your handling code here:
        int f = propTab.getSelectedRow();
       
        proTxt.setText(propTab.getValueAt(f,1).toString());
        preTxt.setText(propTab.getValueAt(f,2).toString());
        codpTxt.setText(propTab.getValueAt(f,0).toString());
  
       
  //    Double pre = Double.parseDouble(propTab.getValueAt(f, 2).toString());
    }//GEN-LAST:event_propTabMouseClicked

    private void borBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borBotActionPerformed
        // TODO add your handling code here:
  
         int codp= Integer.parseInt(codpTxt.getText()); 
        
         if (JOptionPane.showConfirmDialog(null, "¿Desea anular?", "Anular", JOptionPane.YES_NO_OPTION) == 0) {
        obj.eliminar(codp);
        verProductos();
       
        
       
        
        
       }  
    }//GEN-LAST:event_borBotActionPerformed

    private void ingpBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingpBotActionPerformed
        // TODO add your handling code here:
        if(!validap()) return ;
        Producto p = new Producto();
        p.setNompro(proTxt.getText());
        p.setPrecio(Double.parseDouble(preTxt.getText()));
        
        obj.adicion(p);
        verProductos();
       
       
        
    }//GEN-LAST:event_ingpBotActionPerformed

    private void codpTxtComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_codpTxtComponentHidden
        // TODO add your handling code here:
    }//GEN-LAST:event_codpTxtComponentHidden

    private void nconTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nconTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nconTxtActionPerformed

    private void eliBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliBotActionPerformed
        // TODO add your handling code here:

        int idcod = Integer.parseInt(cocTxt.getText());

        if (JOptionPane.showConfirmDialog(null, "¿Desea anular?", "Anular", JOptionPane.YES_NO_OPTION) == 0) {
            obj.anula(idcod);verdatos();
            limpiar();
        }

    }//GEN-LAST:event_eliBotActionPerformed

    private void nomLTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomLTxtKeyReleased

        String cod = nomLTxt.getText().toLowerCase().trim();

        if (cod.isEmpty()) {
            verdatos();
        } else {
            // Si el campo no está vacío, llamar al método busdatos
            busdatos(cod);
        }

    }//GEN-LAST:event_nomLTxtKeyReleased

    private void nomLTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomLTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomLTxtActionPerformed

    private void lisTabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lisTabMouseClicked
        // TODO add your handling code here:
        int f = lisTab.getSelectedRow();
        cocTxt.setText(lisTab.getValueAt(f,0).toString());
        //     cocTxt.setText("");

    }//GEN-LAST:event_lisTabMouseClicked

    private void cocTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cocTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cocTxtActionPerformed

    private void impBotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_impBotActionPerformed
        // TODO add your handling code here:
        Document document = new Document();
    try {
        PdfWriter.getInstance(document, new FileOutputStream("Descargas"));
        document.open();
        String contenido = areaCTxt.getText(); // Obtén el contenido del área de texto
        document.add(new Paragraph(contenido));
        document.close();
        System.out.println("Archivo PDF generado correctamente.");
    } catch (DocumentException | FileNotFoundException e) {
        e.printStackTrace();
    }

        this.setVisible(false);
        
    }//GEN-LAST:event_impBotActionPerformed
      void verdeta(){
        DefaultTableModel dt=(DefaultTableModel)conTab.getModel();
        dt.setRowCount(0);
        double sm=0;
        for(Detalle x:lista){
            Object v[]={x.getCodp(),x.getNompro(),x.getPrecio(),x.getCantidad(),x.totpro()};
            dt.addRow(v);
            sm=sm+x.totpro();
        }
        totTxt.setText(""+sm);
    }
 
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FRestaurante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FRestaurante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FRestaurante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FRestaurante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FRestaurante().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AnuBot;
    private javax.swing.JTextArea areaCTxt;
    private javax.swing.JButton borBot;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField canTxt;
    private javax.swing.JTextField cocTxt;
    private javax.swing.JTextField codTxt;
    private javax.swing.JTextField codpTxt;
    private javax.swing.JButton conBot;
    private javax.swing.JTable conTab;
    private javax.swing.JButton eliBot;
    private javax.swing.JButton genBot;
    private javax.swing.JButton impBot;
    private javax.swing.JButton ingBot;
    private javax.swing.JButton ingpBot;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable lisTab;
    private javax.swing.JTextField nconTxt;
    private javax.swing.JTextField nomLTxt;
    private javax.swing.JTextField nomTxt;
    private javax.swing.JTextField preTxt;
    private javax.swing.JTable proTab;
    private javax.swing.JTextField proTxt;
    private javax.swing.JTextField probTxt;
    private javax.swing.JTable propTab;
    private javax.swing.JTextField totTxt;
    // End of variables declaration//GEN-END:variables

    private void verDatos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    
       }
