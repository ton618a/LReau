
package Restaurante;


public class Cliente extends Consumo {
    private int id_cliente;
    private String dni;
    private String nombrec;
    private String apellido;
    static int cuenta=1;

    public Cliente(String dni, String nombrec, String apellido, String nombre, double importeTotal) {
        super(nombre, importeTotal);
        this.id_cliente = cuenta;
        this.dni = dni;
        this.nombrec = nombrec;
        this.apellido = apellido;
        cuenta++;
    }


    
    
}
