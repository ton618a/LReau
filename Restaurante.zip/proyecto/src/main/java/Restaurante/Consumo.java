 
package Restaurante;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;



public   class Consumo  {
    private int idcod;
    private String nombre;
    private double importeTotal;
    private LocalDateTime fechaHora;
  

    public Consumo( String nombre, double importeTotal) {
     
        this.nombre = nombre;
        this.importeTotal = importeTotal;
        this.fechaHora = LocalDateTime.now(); 
        // cuenta++;
    }

    public Consumo() {
    }

    
  

    
     public LocalDateTime getFechaHora() {
        return fechaHora;
    }
     //
    public void setFechaHora(LocalDateTime fechaHoraActual) {
        this.fechaHora = fechaHoraActual;
    }
    public void mostrarFechaHoraActual() {
        LocalDateTime fechaHoraActual = LocalDateTime.now();

        // Formatear la fecha y hora como una cadena
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String fechaHoraFormateada = fechaHoraActual.format(formato);
    }
    
    public int getIdcod() {
        return idcod;
    }

    public void setIdcod(int idcod) {
        this.idcod = idcod;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getImporteTotal() {
        return importeTotal;
    }

    public void setImporteTotal(double importeTotal) {
        this.importeTotal = importeTotal;
    }
    public void getImporteTotal(double importeTotal) {
        this.importeTotal = importeTotal;
    }

    void setNombref(String text) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setRuc(String text) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    

  

    
   
    
    

    
  
    
    




   
}