/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Restaurante;

/**
 *
 * @author ton
 */
public class Detalle extends Producto{
    private int nroped;
    private int cantidad;

    public double totpro(){
    return cantidad*super.getPrecio();
    }

    public int getNroped() {
        return nroped;
    }

    public void setNroped(int nroped) {
        this.nroped = nroped;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    
    
    
}